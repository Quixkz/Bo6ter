const config = {
    token: '',
    prefix: ''
}

module.exports = config;