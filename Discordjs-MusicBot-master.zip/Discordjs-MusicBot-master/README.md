
<h1 align="center">Discordjs Music Bot - Advanced</h1>
<h1 align="center"><img src ="https://github.com/Mercurydev986/Discordjs-MusicBot-Tutorial/blob/master/sound.gif?raw=true"></h1>
 
 
## <img src="https://img.icons8.com/nolan/2x/youtube-music.png" width="25" height="25">Youtube Tutorial<img src="https://img.icons8.com/nolan/2x/youtube-music.png" width="25" height="25">

https://www.youtube.com/watch?v=lqRRKQQ_D5g&t=19s

##  <img src="https://img.icons8.com/ultraviolet/2x/burn-cd.png" height="30" width = "30">Remix The Project<img src="https://img.icons8.com/ultraviolet/2x/burn-cd.png" height="30" width = "30">
[![Remix on Glitch](https://cdn.glitch.com/2703baf2-b643-4da7-ab91-7ee2a2d00b5b%2Fremix-button.svg)](https://glitch.com/edit/#!/import/github/Mercurydev986/Discordjs-MusicBot-Tutorial/)

## <img src="https://img.icons8.com/ultraviolet/2x/user-group-man-woman.png" width="30" height="30">Made By<img src="https://img.icons8.com/ultraviolet/2x/user-group-man-woman.png" width="30" height="30">

Nithish#6593 - Owner | Developer

## <img src="https://img.icons8.com/nolan/2x/camera.png" height="30" width="30"> SCREENSHOTS<img src="https://img.icons8.com/nolan/2x/camera.png" height="30" width="30">

<img src="https://cdn.discordapp.com/attachments/764452688813228043/764452953767411712/unknown.png">

<img src="https://cdn.discordapp.com/attachments/764452688813228043/764453346689155083/unknown.png">

<img src="https://cdn.discordapp.com/attachments/764452688813228043/764453472791298049/unknown.png">

## <img src="https://img.icons8.com/nolan/2x/gold-bars.png" height ="30" width="30">SPECIALITY<img src="https://img.icons8.com/nolan/2x/gold-bars.png" height ="30" width="30">

This music bot is programmed in the way that it will scrape the youtube website directly, which means No more annoying youtube-api-key is needed!

## CREDITS
[@icrawl](https://github.com/iCrawl)
Thanks to icrawl, queue system is partially adapted from icrawl's [Music Bot Repo](https://github.com/iCrawl/discord-music-bot)
